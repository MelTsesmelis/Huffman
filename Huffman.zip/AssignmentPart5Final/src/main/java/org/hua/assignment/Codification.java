/* PART 3 
 * This class made to read and take informations of tree.dat (file is based on huffman`s tree)  
 * and make a codification based on them
 */
package org.hua.assignment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;

/**
 * @authors Meletios Tsesmelis (it219105) 
 * Spuridwn Mouxlianiths (it21958)              team0
 * Apostolos Dhmhtriou (it219138)
 *
 */
public class Codification {

    public void basedInHuffmanTree() throws FileNotFoundException, IOException, ClassNotFoundException {
        File codesDat = new File("codes.dat");
        if (!codesDat.exists()) {
            //Read file tree.dat 
            FileInputStream FileInputTree = new FileInputStream("tree.dat");
            //create object for input my file 
            ObjectInputStream οbjInput = new ObjectInputStream(FileInputTree);
            //take the roor of huffman`s tree (so we have all the tree practicaly)
            Node huffmanTreeRoot = (Node) οbjInput.readObject();
            //make object for print writer 
            PrintWriter printWriter = new PrintWriter("codes.dat");
            //give root and print writer on method to make the codification
            toCodificate(huffmanTreeRoot, printWriter);
            //after write on file , we close writer
            printWriter.close();
        }else{
            System.out.println("\tcodes.dat already exist!So I skip creation process!");
        }
    }

    private void toCodificate(Node root, PrintWriter pw) {
        Deque<String> deque = new ArrayDeque<>(); //create an empty queue
        Iterator<String> iterator = deque.iterator();
        try {
            postorderIter(root, deque, iterator, pw, "");
        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
    }
      
    
    private void postorderIter(Node root, Deque<String> deque, Iterator<String> iterator, PrintWriter pw, String code) {
        if (root != null) {
            //add code to the queue
            deque.add(code);
            //if the queue has an empty element (which should be the first element) then remove it
            if (deque.contains("")) {
                deque.removeFirst();
            }

            //if left and right child of root are null then print the character and the code to the file
            if (root.getLeftChild() == null && root.getRightChild() == null) {
                pw.printf("%d ", root.getCharacter());
                for (iterator = deque.iterator(); iterator.hasNext();) {
                    pw.printf("%s", iterator.next());
                }
                pw.println();
                deque.removeLast(); //remove last element of deque
                return;
            }
            //call postorderIter recursively with the left child and the right child
            postorderIter(root.getLeftChild(), deque, iterator, pw, "0");
            postorderIter(root.getRightChild(), deque, iterator, pw, "1");
            if (!deque.isEmpty()) {
                deque.removeLast();
            }
        }
    }
}
