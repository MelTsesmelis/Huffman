/*
 * this class created to make nodes with some data and children
 * and help class MakeTree to create Huffman`s tree
 */
package org.hua.assignment;

/**
 * @authors Meletios Tsesmelis (it219105) 
 * Spuridwn Mouxlianiths (it21958)              team0
 * Apostolos Dhmhtriou (it219138)
 *
 */
import java.io.Serializable;

public class Node implements Serializable {
    private int frequency;
    private int character;
    private Node leftChild; //left child -> Arr[(2 * i) + 1]
    private Node rightChild; //right child -> Arr[(2 * i) + 2]

    public Node() {
        this.leftChild = null;
        this.rightChild = null;
    }

    public Node getLeftChild() {
        return leftChild;
    }

    public void setLeftChild(Node leftChild) {
        this.leftChild = leftChild;
    }

    public Node getRightChild() {
        return rightChild;
    }

    public void setRightChild(Node rightChild) {
        this.rightChild = rightChild;
    }

    public int getFrequency() {
        return frequency;
    }

    public void setFrequency(int frequency) {
        this.frequency = frequency;
    }

    public int getCharacter() {
        return character;
    }

    public void setCharacter(int character) {
        this.character = character;
    }

}