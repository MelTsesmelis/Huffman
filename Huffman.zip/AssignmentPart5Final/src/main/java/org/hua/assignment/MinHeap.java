/*
 *this class made to calculate the minimum heap of tree and put them on top
 *based in MinHeapInterface
 */

package org.hua.assignment;

/**
 * @authors Meletios Tsesmelis (it219105) 
 * Spuridwn Mouxlianiths (it21958)              team0
 * Apostolos Dhmhtriou (it219138)
 *
 */

import java.util.NoSuchElementException;

public class MinHeap implements MinHeapInterface {

    public static final int DEFAULT_CAPACITY = 129;
    private Node[] array;
    private int size;

    //make contructor
    public MinHeap() {
        this.size = 0;
        this.array = new Node[DEFAULT_CAPACITY];
    }

    //make contructor with argument an Node array 
    public MinHeap(Node[] array) {
        int n = array.length;
        this.array = new Node[DEFAULT_CAPACITY];
        this.size = n;

        System.arraycopy(array, 0, this.array, 1, n);
        for (int i = this.array.length / 2; i > 0; i--) {
            fixdown(i);
        }
    }

    //instert and element 
    @Override
    public void insert(Node element) {
        if (size + 1 >= array.length) {
            doubleCapacity();
        }
        array[++size] = element;
        fixup(size);
    }

    // find element with minimum element
    @Override
    public Node findMin() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        return array[1];
    }

    //delete minimum element of array 
    @Override
    public void deleteMin() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        Node result = array[1];
        array[1] = array[size];
        array[size] = null;
        size--;
        fixdown(1);
    }

    //check if array is empty
    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void clear() {
        for (int i = 1; i <= size; i++) {
            array[i] = null;
        }
        size = 0;
    }

    //usefull methods
    private void swap(int i, int j) {
        Node tmp = array[i];
        array[i] = array[j];
        array[j] = array[i];
        array[j] = tmp;
    }

    private void fixup(int size) {
        assert size >= 1 && size <= this.size;
        while (size > 1 && Integer.compare(array[size].getFrequency(), array[size / 2].getFrequency()) < 0) {
            swap(size, size / 2);
            size = size / 2;
        }
    }

    //double the capacity of the array
    private void doubleCapacity() {
        int newCapacity = (array.length - 1) * 2;
        Node[] newArray = new Node[newCapacity];
        for (int i = 1; i <= size; i++) {
            newArray[i] = array[i];
        }
        array = newArray;
    }

    private void fixdown(int k) {
        while (2 * k <= size) {
            int j = 2 * k;
            //check if left child's frequency is less than it's father's.
            //If true increment j (go to right child)
            if (j + 1 <= size) {
                if (array[j + 1].getFrequency() < array[j].getFrequency()) {
                    j++;
                }
            }
            //check if father's frequency is less than or equal to child's frequency
            //If true ok
            if (array[k].getFrequency() <= array[j].getFrequency()) {
                break;
            }
            //else swap father and child
            swap(k, j);
            k = j;
        }
    }
}
