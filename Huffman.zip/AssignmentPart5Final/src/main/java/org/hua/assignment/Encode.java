/*     PART 4 (includes part 1,2,3)
 * This class has a main 
 * made to encode ASCII character of a input file (name given by user like argument)  
 * to huffman codificated characters(same as before) and put then in  a output file (name given by user like argument)  
 */
package org.hua.assignment;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.URL;
import java.io.*;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Scanner;

/**
 * @authors Meletios Tsesmelis (it219105) 
 * Spuridwn Mouxlianiths (it21958)              team0
 * Apostolos Dhmhtriou (it219138)
 *
 */
public class Encode implements Serializable {

    public static void main(String[] args) {

        try {
            //check if user entered 2 parameters one for the input file and one for the output file
            if (args.length != 2) {
              System.out.println("PART 4 cannot be executed");
              System.out.println("Usage: java -cp target/Assignment-1.0-SNAPSHOT.jar org.hua.assignment.App (inputFile) (outputFile)");
              System.exit(0);
            }

            //input the first file
            File inputFile = new File(args[0]);//args[0]
            
           //check if file exists
            if (!inputFile.exists()) {
                System.out.println("Part 4 cannot be executed correctly");
                System.out.println("File " + args[0] + " does not exist");
                System.exit(0);
            }

            //PART 1 BELLOW
            //load 3 files from url
            URL firstFile = new URL("https://www.gutenberg.org/files/1342/1342-0.txt");
            URL secondFile = new URL("https://www.gutenberg.org/files/11/11-0.txt");
            URL thirdFile = new URL("https://www.gutenberg.org/files/2701/2701-0.txt");
            Frequencies lets = new Frequencies();
            lets.calculateAsciiFrequenciesOf(firstFile, secondFile, thirdFile);
            //END OF PART 1

            //PART 2 BELOW
            MakeTree make = new MakeTree();
            make.huffmanTree();
            //END OF PART 2 

            //PART 3 BELLOW
            Codification codification = new Codification();
            codification.basedInHuffmanTree();
            //END OF PART 3

            //PART 4 BELLOW
            int i, j;
            String[] codes = new String[128];
            i = 0;
            int k = 0;
            j = 1;
            int[] characters = new int[128];
            //read file codes.dat
            try {
                File codesFile = new File("codes.dat");
                Scanner myReader = new Scanner(codesFile);
                //read codes.dat
                while (myReader.hasNext()) {
                    //save codes from file to codes[] array
                    String data = myReader.next();
                    //int j represents the column in the file
                    //column 1 is the character and column 2 is the codification
                    if (j == 1) {
                        characters[k] = Integer.parseInt(data);
                        j++;
                        k++;
                    } else {
                        codes[i] = data;
                        i++;
                        j = 1;
                    }
                }
                myReader.close();
            } catch (FileNotFoundException e) {
                System.out.println("Error:" + e);
            }

            //sort the characters[] and codes[] array
            for (i = 0; i < 128; i++) {
                for (j = i + 1; j < 128; j++) {
                    if (characters[i] > characters[j]) {
                        int temp = characters[i];
                        characters[i] = characters[j];
                        characters[j] = temp;

                        String tempStr = codes[i];
                        codes[i] = codes[j];
                        codes[j] = tempStr;
                    }
                }
            }
            //now characters[0] is ASCII character 0 and codes[0] has the codification for the ASCII character 0

            //read input file 
            FileReader fileReader = new FileReader(inputFile);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            int c = 0;
            String[] fileCharacters = new String[(int) inputFile.length()];
            i = 0;
            boolean hasAsciiCharacter = false;
            while ((c = bufferedReader.read()) != -1) {
                //get ascii characters only 
                if (c >= 0 && c <= 127) {
                    fileCharacters[i] = codes[c];
                    i++;
                } else {
                    hasAsciiCharacter = true;
                }
            }
            if (hasAsciiCharacter) {
                System.out.println("\n\tBE CAREFUL! this program works correctly with 128 first characters of ASCII table!");
            }

            //fileCharacters[] array now has the characters of the input file
            char[] ch;
            //use deque like stack to save letter by letter the codification
            Deque<Character> deque = new ArrayDeque<>();
            for (i = 0; i < fileCharacters.length; i++) {
                //will be null if character is not ascii
                if (fileCharacters[i] != null) {
                    ch = fileCharacters[i].toCharArray();
                    for (char l : ch) {
                        deque.addLast(l);
                    }
                }
            }
            //write bits to file
            File outputFile = new File(args[1]); //arg[1]
            FileOutputStream fOutputStream= new FileOutputStream(outputFile);
            DataOutputStream dataOut = new DataOutputStream(fOutputStream);
            //ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            
            
            byte numberOfBits =(byte)(deque.size()%8); //so i have on last byte the usefulbits
            dataOut.writeByte(numberOfBits);//we write this number
            //use mask to create each byte
            byte bitmask = 0;
            int savedByte;
            i = 0;
            k = 0;
            int sum = 0;
            while (!deque.isEmpty()) {
                while (k < 8) {
                    if (!deque.isEmpty()) {
                        if (deque.getFirst().compareTo('1') == 0) //if element is equal '1' then 
                        {
                            savedByte = 1; //make a byte
                            savedByte = (byte) (savedByte << (7 - k)); //shift this (00000001) left 8-(k+1) times to go to current bit cause i start with k=0
                            bitmask = (byte) (savedByte | bitmask); //use OR to save last information (see explain on report)         
                        }
                        i++;
                        deque.removeFirst();
                    }
                    k++;
                } //so we have a byte 
                sum++;
                dataOut.write(bitmask);
                bitmask = 0; //prepare mask for next byte
                k = 0; //prepare counter for next byte
            }
           dataOut.close();
            //END OF PART 4 
        } catch (IOException | NumberFormatException | ClassNotFoundException ex) {
            System.out.println("Error:" + ex);
        }
    }
}
