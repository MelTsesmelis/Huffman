/*     PART 1
 * This class take 3 files using URL
 * and calculate the frequencies of each element of 128 of ASCII TABLE 
 * for that files
 */
package org.hua.assignment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * @authors Meletios Tsesmelis (it219105) 
 * Spuridwn Mouxlianiths (it21958)              team0
 * Apostolos Dhmhtriou (it219138)
 *
 */
public class Frequencies {

    public void calculateAsciiFrequenciesOf(URL url1, URL url2, URL url3) throws MalformedURLException, IOException {
        System.out.println("Running...");
        File outputFileFrequencies = new File("frequencies.dat");
        //if frequencies.dat already exist don`t create it again
        if (!outputFileFrequencies.exists()) {
            //declare frequencies array
            int[] frequencies = new int[128];
            //use method to take frequencies of that 3 files
            frequencies = frequenciesForFile(frequencies, url1);
            frequencies = frequenciesForFile(frequencies, url2);
            frequencies = frequenciesForFile(frequencies, url3);
            //create file to output
            //write to file
            FileWriter writer = new FileWriter("frequencies.dat");
            for (int i = 0; i < 128; i++) {
                writer.write(i + " -> ");
                writer.write(frequencies[i] + " \n");
            }
            writer.close();
        }else{
            System.out.println("\tfrequencies.dat already exist!So I skip creation process!");
        }
    }

    private static int[] frequenciesForFile(int[] freq, URL file) throws IOException {
        BufferedReader firstFileReader = new BufferedReader(new InputStreamReader(file.openStream()));
        //read one character at a time and store it to firstFileBuffer
        int FileBuffer; //contains one character at a time
        while ((FileBuffer = firstFileReader.read()) != -1) {
            //if the character stored in firstFileBuffer is in this range [0,127] then it it an ASCII character
            if (FileBuffer >= 0 && FileBuffer <= 127) {
                freq[FileBuffer]++; //increment the frequency of the character by one
            }
        }
        return freq;//return array , so i can use it to next file
    }

}
