/* PART 5
 * This class has a main 
 * made to decode huffman coded characters  of a input file (name given by user like argument)  
 * to ASCII  characters and put then in  a output file (name given by user like argument)  
 */
package org.hua.assignment;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.util.BitSet;

/**
 * @authors Meletios Tsesmelis (it219105)
 * Spuridwn Mouxlianiths (it21958)          team0
 * Apostolos Dhmhtriou (it219138)
 *
 */
public class Decode {

    public static void main(String[] args) {

        try {
            //check if user entered 2 parameters one for the input file and one for the output file
            if (args.length != 2) {
               System.out.println("PART 5 cannot be executed");
               System.out.println("Usage: java -cp target/Assignment-1.0-SNAPSHOT.jar org.hua.assignment.App (inputFile) (outputFile)");
               System.exit(0);
            }

            //input the first file
            File inputFile = new File(args[0]);
            //check if file exists
            if (!inputFile.exists()) {
                System.out.println("Part 5 cannot be executed correctly");
                System.out.println("File " + args[0] + " does not exist");
                System.exit(0);
            }

            //PART 1 BELLOW
            //load 3 files from url
            URL firstFile = new URL("https://www.gutenberg.org/files/1342/1342-0.txt");
            URL secondFile = new URL("https://www.gutenberg.org/files/11/11-0.txt");
            URL thirdFile = new URL("https://www.gutenberg.org/files/2701/2701-0.txt");
            Frequencies lets = new Frequencies();
            lets.calculateAsciiFrequenciesOf(firstFile, secondFile, thirdFile);
            //END OF PART 1
            //PART 2 BELOW
            MakeTree make = new MakeTree();
            make.huffmanTree();
            //END OF PART 2
            //PART 3 BELLOW
            Codification codification = new Codification();
            codification.basedInHuffmanTree();
            //END OF PART 3

            //PART 5 BELLOW
            //Read file tree.dat 
            FileInputStream FileInputTree = new FileInputStream("tree.dat");
            //create object for input my file 
            ObjectInputStream οbjInput = new ObjectInputStream(FileInputTree);
            //take the root of huffman`s tree (so we have all the tree practicaly)
            Node huffmanTreeRoot = (Node) οbjInput.readObject();

            //make an array to save bytes of file
            byte[] arrayBytes = new byte[(int) inputFile.length()];
            //use InputStream to read input file 
            FileInputStream in = new FileInputStream(inputFile); //args[0]
            //read all bytes of file
           arrayBytes=in.readAllBytes();
         
           
            //take usefull bits 
            byte numberOfUsefulBits =(byte) arrayBytes[0]; //because first is the number of usefull bits
      
            /*
              make a bitsSet array to store in each cell of it 
              each cell of arrayByte.So in bitSet[1] we will have 
              the possiotions of 1(true) searched on each bit of that byte
             */
            BitSet[] bitSets = new BitSet[arrayBytes.length];

            //make a print writer to write on output file 
            PrintWriter output = new PrintWriter(args[1]);
            //store huffman`s root 
            Node currentNode = huffmanTreeRoot;
            //so while we have bytes do ...
            for (int i = 1; i < arrayBytes.length; i++) {
                //for each element like we said store bytes` information (where has true->1)
                bitSets[i-1] = BitSet.valueOf(new byte[]{arrayBytes[i]});
                /*
                  like we say on report, because on encode we didn`t use bitset
                  but mask and shifts. So if we give 
                */
                for (int j = 7; j >= 0; j--) { 
                    if (i < arrayBytes.length - 1) { //so we are not on last byte
                        if (bitSets[i-1].get(j)) //if its TRUE-> this bit is 1 so go right
                            currentNode = currentNode.getRightChild();
                         else //so this bit is 0 so go left 
                            currentNode = currentNode.getLeftChild();
                        
                        //write leaf - character on output file
                        if (currentNode.getLeftChild() == null && currentNode.getRightChild() == null) {
                            output.printf("%c", (char) currentNode.getCharacter());
                            currentNode = huffmanTreeRoot; //and return on root
                        }
                    } else {//so we are on last byte 
                        if (j >= (8 - numberOfUsefulBits)) { //do this for useful bits,ignore others
                            if (bitSets[i-1].get(j))  //so bit is 1
                                currentNode = currentNode.getRightChild();
                             else //so bit is 0 
                                currentNode = currentNode.getLeftChild();
                            
                              //write leaf - character on output file
                            if (currentNode.getLeftChild() == null && currentNode.getRightChild() == null)
                            {
                                output.printf("%c", (char) currentNode.getCharacter());
                                currentNode = huffmanTreeRoot; //return on root
                            }
                        }
                    }
                }
            }
            output.close();
        } catch (IOException | NumberFormatException | ClassNotFoundException ex) {
            System.out.println("Error:" + ex);
        }
    }
}
