/*
 * PART 2
 * this class made to read frequencies from frequencies.dat and
 * create a tree based on  Huffman`s rules
 */
package org.hua.assignment;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

/**
 * @authors Meletios Tsesmelis (it219105) 
 * Spuridwn Mouxlianiths (it21958)              team0
 * Apostolos Dhmhtriou (it219138)
 *
 */
public class MakeTree {

    public void huffmanTree() throws FileNotFoundException, IOException {
        int[] frequencies = new int[128];
        //check if already exist
        File treeDat = new File("tree.dat");
        if (!treeDat.exists()) {
            //open file frequencies.dat
            File myFile = new File("frequencies.dat");
            Scanner reader = new Scanner(myFile); //read from the file
            int i = 0;
            int j = 0;
            while (reader.hasNext()) {//while you have something to read , go on
                String data = reader.next();
                /*because the file looks like this: (1 -> 15648) etc we read each token and only the third token
                of each line gets stored to the array. The third token in each loop is the frequency
                 */
                j++;
                if (j == 3 && i < 128) {
                    frequencies[i] = Integer.parseInt(data); //convert string type to integer and store it to array frequencies
                    i++; //for each element of frequencies-array
                    j = 0;
                }
            }
            //close the reader
            reader.close();

            //create a new array of nodes that contains the frequencies and the characters
            Node[] nodes = new Node[frequencies.length];
            for (i = 0; i < nodes.length; i++) {
                nodes[i] = new Node();
                nodes[i].setFrequency(frequencies[i]);
                nodes[i].setCharacter(i);
            }

            //create huffmanTree
            HuffmanRules huffmanTree = new HuffmanRules(nodes);
            Node tree = huffmanTree.create();

            //output to a file tree.dat
            FileOutputStream file = new FileOutputStream("tree.dat");
            ObjectOutputStream outputObject = new ObjectOutputStream(file);
            outputObject.writeObject(tree); //write the object tree to the file tree.dat
            outputObject.close();
        }else{
            System.out.println("\ttree.dat already exist!So I skip creation process!");
        }
    }
}
