/*
 * this class made to help class MakeTree 
 *to make a tree based in huffman rules 
 */
package org.hua.assignment;

/**
 * @authors Meletios Tsesmelis (it219105) 
 * Spuridwn Mouxlianiths (it21958)              team0
 * Apostolos Dhmhtriou (it219138)
 *
 */
import java.io.*;

public class HuffmanRules implements Serializable {

    private final Node[] nodesArray; //nodesArray will already be sorted

    public HuffmanRules(Node[] nodesArray) {

        this.nodesArray = new Node[nodesArray.length];

        for (int i = 0; i < nodesArray.length; i++) {
            this.nodesArray[i] = new Node();
            this.nodesArray[i].setFrequency(nodesArray[i].getFrequency());
            this.nodesArray[i].setCharacter(nodesArray[i].getCharacter());
        }

    }

    public Node create() {
        //create minHeap
        MinHeap minHeap = new MinHeap();

        //create a node for each frequency and add it to the heap
        for (Node nodesArray1 : nodesArray) {
            Node node = new Node();
            node.setFrequency(nodesArray1.getFrequency());
            node.setCharacter(nodesArray1.getCharacter());
            node.setLeftChild(nodesArray1.getLeftChild());
            node.setRightChild(nodesArray1.getRightChild());
            minHeap.insert(node);
        }

        //create huffman tree
        Node root = null;
        while (minHeap.size() > 1) {
            //get the first min and store it to tmp1, then delete it from heap
            Node tmp1 = minHeap.findMin();
            minHeap.deleteMin();

            //get the second min and store it to tmp2, then delete it from heap
            Node tmp2 = minHeap.findMin();
            minHeap.deleteMin();

            //create a new node tmp which will have as frequency the sum of tmp1's and tmp2's frequencies
            //it's left child will be the first min (tmp1)
            //it's right child will be the second min (tmp2)
            Node tmp = new Node();

            tmp.setFrequency(tmp1.getFrequency() + tmp2.getFrequency());
            tmp.setLeftChild(tmp1);
            tmp.setRightChild(tmp2);
            tmp.setCharacter('-');
            root = tmp; //set the root as tmp and insert tmp to the heap
            minHeap.insert(tmp);
        }

        return root;
    }

}
