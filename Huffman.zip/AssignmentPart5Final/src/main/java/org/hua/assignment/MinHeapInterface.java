/*
 * This Interface created to help us create a MinHeap
*/
package org.hua.assignment;

/**
 * @authors Meletios Tsesmelis (it219105) 
 * Spuridwn Mouxlianiths (it21958)              team0
 * Apostolos Dhmhtriou (it219138)
 *
 */
public interface MinHeapInterface {
    /**
	 * Insert an element into the heap
	 * 
	 * @param elem the element
	 */
	void insert(Node elem);

	/**
	 * Find the minimum element
	 * 
	 * @return the minimum element
	 */
        
	Node findMin();

	/**
	 * Delete the minimum element
	 * 
	 */
	void deleteMin();

	/**
	 * Check if the heap is empty
	 * 
	 * @return true if empty, false otherwise
	 */
	boolean isEmpty();

	/**
	 * Get the size of the heap
	 * 
	 * @return the size of the heap
	 */
	int size();

	/**
	 * Clear the heap
	 */
	void clear();
}
